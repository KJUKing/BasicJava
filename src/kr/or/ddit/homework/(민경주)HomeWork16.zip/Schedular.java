package kr.or.ddit.homework.HomeWork16;

public interface Schedular {
    public void getNextCall();

    public void sendCallToAgent();
}
