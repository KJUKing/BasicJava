package kr.or.ddit.homework.homework15;

public abstract class Game {

    public abstract int playGame(int money);

    public abstract int payMoney(int money);

}
